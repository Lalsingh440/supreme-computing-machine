import { useState } from "react";
import Eyebrow from "../components/Eyebrow";
import { offices, contact } from "../data/services";

export default function Contact() {
  const [active, setActive] = useState(0);
  const [sent, setSent] = useState(false);

  const submit = (e) => {
    e.preventDefault();
    setSent(true);
  };

  return (
    <div>
      <section className="bg-navy text-paper">
        <div className="max-w-6xl mx-auto px-5 md:px-8 py-16 md:py-20">
          <Eyebrow dark>Get In Touch</Eyebrow>
          <h1 className="font-display font-800 uppercase text-4xl md:text-5xl">Contact Us</h1>
          <p className="mt-5 max-w-2xl text-stone/80 leading-relaxed">
            Reach our Abu Dhabi head office or Dubai branch directly, or send a proposal request below.
          </p>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-5 md:px-8 py-16 grid md:grid-cols-2 gap-12">
        <div>
          <Eyebrow>Branch Selector</Eyebrow>
          <div className="flex gap-2 mb-6">
            {offices.map((o, i) => (
              <button
                key={o.city}
                onClick={() => setActive(i)}
                className={`font-mono text-xs uppercase tracking-widest2 px-5 py-3 border transition-colors duration-200 ${
                  active === i ? "bg-navy text-paper border-navy" : "border-stone text-navy/70 hover:border-navy"
                }`}
              >
                {o.city.split(" — ")[0].split(" ")[0]}
              </button>
            ))}
          </div>
          <div className="border border-stone p-6">
            <p className="font-display font-700 uppercase text-xl text-navy">{offices[active].city}</p>
            <p className="text-ink/70 mt-2 leading-relaxed">{offices[active].address}</p>
          </div>

          <div className="mt-8 border-t border-stone pt-8 space-y-2 font-mono text-sm">
            <p className="text-ink/50 uppercase tracking-widest2 text-[11px] mb-2">Direct Lines</p>
            <p>Main line: <span className="text-navy">{contact.phone}</span></p>
            <p>WhatsApp: <span className="text-navy">{contact.whatsapp}</span></p>
            <p>Careers: <span className="text-navy">{contact.careersEmail}</span></p>
          </div>
        </div>

        <div>
          <Eyebrow>Proposal Request</Eyebrow>
          {sent ? (
            <div className="border border-gold bg-navy text-paper p-8">
              <p className="font-display font-700 uppercase text-xl">Request received.</p>
              <p className="text-stone/70 mt-2">
                A member of the Star Security team will follow up shortly.
              </p>
            </div>
          ) : (
            <form onSubmit={submit} className="space-y-4">
              <div>
                <label className="block font-mono text-[11px] uppercase tracking-widest2 text-navy/60 mb-1">Name</label>
                <input required type="text" className="w-full border border-stone px-4 py-3 bg-paper focus:border-navy outline-none" />
              </div>
              <div>
                <label className="block font-mono text-[11px] uppercase tracking-widest2 text-navy/60 mb-1">Company</label>
                <input type="text" className="w-full border border-stone px-4 py-3 bg-paper focus:border-navy outline-none" />
              </div>
              <div>
                <label className="block font-mono text-[11px] uppercase tracking-widest2 text-navy/60 mb-1">Email</label>
                <input required type="email" className="w-full border border-stone px-4 py-3 bg-paper focus:border-navy outline-none" />
              </div>
              <div>
                <label className="block font-mono text-[11px] uppercase tracking-widest2 text-navy/60 mb-1">
                  What do you need secured?
                </label>
                <textarea rows={4} className="w-full border border-stone px-4 py-3 bg-paper focus:border-navy outline-none" />
              </div>
              <button
                type="submit"
                className="bg-navy text-paper font-mono text-xs uppercase tracking-widest2 px-7 py-4 hover:bg-gold hover:text-void transition-colors duration-200"
              >
                Submit Request
              </button>
            </form>
          )}
        </div>
      </section>
    </div>
  );
}
