import { useState } from "react";
import { Link } from "react-router-dom";
import Eyebrow from "../components/Eyebrow";
import { services, categories } from "../data/services";

const steps = [
  {
    q: "Facility type",
    options: ["Commercial", "Residential", "Infrastructure", "Event"],
  },
  {
    q: "Primary vulnerability",
    options: ["CCTV gaps", "Access tracking", "Perimeter breaches", "No staff training"],
  },
  {
    q: "Timeline",
    options: ["Immediate", "1–3 months", "Just gathering information"],
  },
];

const recommendation = (answers) => {
  if (answers[1] === "CCTV gaps") return services.find((s) => s.slug === "cctv-monitoring");
  if (answers[1] === "Access tracking") return services.find((s) => s.slug === "smart-security");
  if (answers[1] === "Perimeter breaches") return services.find((s) => s.slug === "manned-guarding");
  return services.find((s) => s.slug === "risk-consultancy");
};

export default function Services() {
  const [filter, setFilter] = useState("All");
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState([]);

  const filtered = filter === "All" ? services : services.filter((s) => s.category === filter);

  const choose = (option) => {
    const next = [...answers, option];
    setAnswers(next);
    setStep(step + 1);
  };

  const reset = () => {
    setAnswers([]);
    setStep(0);
  };

  const result = step >= steps.length ? recommendation(answers) : null;

  return (
    <div>
      <section className="bg-navy text-paper">
        <div className="max-w-6xl mx-auto px-5 md:px-8 py-16 md:py-20">
          <Eyebrow dark>Capability Directory</Eyebrow>
          <h1 className="font-display font-800 uppercase text-4xl md:text-5xl">What We Do</h1>
          <p className="mt-5 max-w-2xl text-stone/80 leading-relaxed">
            Seven licensed service lines, engineered around regional risk and UAE regulatory compliance.
          </p>
        </div>
      </section>

      {/* Filters + manifest */}
      <section className="max-w-6xl mx-auto px-5 md:px-8 py-16">
        <div className="flex flex-wrap gap-2 mb-8">
          {categories.map((c) => (
            <button
              key={c}
              onClick={() => setFilter(c)}
              className={`font-mono text-xs uppercase tracking-widest2 px-5 py-3 border transition-colors duration-200 ${
                filter === c ? "bg-navy text-paper border-navy" : "border-stone text-navy/70 hover:border-navy"
              }`}
            >
              {c}
            </button>
          ))}
        </div>

        <div className="border-t border-stone">
          {filtered.map((s) => (
            <Link
              key={s.slug}
              to={`/services/${s.slug}`}
              className="group flex items-center gap-6 py-6 border-b border-stone hover:bg-navy transition-colors duration-200 px-2 -mx-2"
            >
              <span className="font-mono text-sm text-gold w-8 shrink-0">{s.code}</span>
              <div className="flex-1">
                <p className="font-display font-700 uppercase text-xl md:text-2xl text-navy group-hover:text-paper transition-colors duration-200">
                  {s.name}
                </p>
                <p className="text-sm text-ink/60 group-hover:text-stone/70 transition-colors duration-200 mt-1 max-w-xl">
                  {s.short}
                </p>
              </div>
              <span className="font-mono text-[10px] uppercase tracking-widest2 text-navy/40 group-hover:text-gold transition-colors duration-200 hidden sm:inline">
                {s.category}
              </span>
            </Link>
          ))}
        </div>
      </section>

      {/* Risk self-assessment widget */}
      <section className="bg-stone/40 border-y border-stone">
        <div className="max-w-3xl mx-auto px-5 md:px-8 py-16">
          <Eyebrow>Self-Assessment</Eyebrow>
          <h2 className="font-display font-800 uppercase text-3xl text-navy mb-8">
            Which service fits your risk profile?
          </h2>

          <div className="bg-paper border border-stone p-8">
            {!result ? (
              <>
                <p className="font-mono text-xs uppercase tracking-widest2 text-navy/50 mb-4">
                  Step {step + 1} of {steps.length} — {steps[step].q}
                </p>
                <div className="grid sm:grid-cols-2 gap-3">
                  {steps[step].options.map((opt) => (
                    <button
                      key={opt}
                      onClick={() => choose(opt)}
                      className="text-left border border-navy/20 px-5 py-4 hover:border-gold hover:bg-navy hover:text-paper transition-colors duration-200"
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </>
            ) : (
              <>
                <p className="font-mono text-xs uppercase tracking-widest2 text-gold mb-3">Recommended Service</p>
                <h3 className="font-display font-700 uppercase text-2xl text-navy mb-2">{result.name}</h3>
                <p className="text-ink/70 leading-relaxed mb-6">{result.short}</p>
                <div className="flex flex-wrap gap-3">
                  <Link
                    to={`/services/${result.slug}`}
                    className="bg-navy text-paper font-mono text-xs uppercase tracking-widest2 px-6 py-3 hover:bg-gold hover:text-void transition-colors duration-200"
                  >
                    View Service
                  </Link>
                  <Link
                    to="/contact"
                    className="border border-navy text-navy font-mono text-xs uppercase tracking-widest2 px-6 py-3 hover:bg-navy hover:text-paper transition-colors duration-200"
                  >
                    Send Report to Star Engineers
                  </Link>
                  <button
                    onClick={reset}
                    className="font-mono text-xs uppercase tracking-widest2 text-ink/50 px-6 py-3 hover:text-navy transition-colors duration-200"
                  >
                    Start over
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}
