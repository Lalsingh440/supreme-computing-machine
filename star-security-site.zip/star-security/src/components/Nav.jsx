import { useState } from "react";
import { Link, NavLink } from "react-router-dom";
import { services } from "../data/services";

const links = [
  { to: "/", label: "Home" },
  { to: "/about", label: "About" },
  { to: "/services", label: "Services" },
  { to: "/contact", label: "Contact" },
];

export default function Nav() {
  const [open, setOpen] = useState(false);
  const [servicesOpen, setServicesOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-navy border-b-2 border-gold">
      <div className="max-w-6xl mx-auto px-5 md:px-8 flex items-center justify-between h-16">
        <Link to="/" className="flex items-baseline gap-2" onClick={() => setOpen(false)}>
          <span className="font-display font-800 text-2xl tracking-wide text-paper leading-none">
            STAR SECURITY
          </span>
          <span className="hidden sm:inline font-mono text-[10px] tracking-widest2 uppercase text-gold">
            Services LLC
          </span>
        </Link>

        <nav className="hidden md:flex items-center gap-8 font-mono text-xs uppercase tracking-widest2">
          {links.map((l) =>
            l.label === "Services" ? (
              <div
                key={l.to}
                className="relative"
                onMouseEnter={() => setServicesOpen(true)}
                onMouseLeave={() => setServicesOpen(false)}
              >
                <NavLink
                  to={l.to}
                  className={({ isActive }) =>
                    `pb-1 border-b-2 transition-colors duration-200 ${
                      isActive ? "text-gold border-gold" : "text-stone border-transparent hover:text-gold"
                    }`
                  }
                >
                  {l.label}
                </NavLink>
                {servicesOpen && (
                  <div className="absolute left-0 top-full mt-0 w-64 bg-navy border border-navyline shadow-2xl shadow-black/40">
                    {services.map((s) => (
                      <Link
                        key={s.slug}
                        to={`/services/${s.slug}`}
                        className="flex items-baseline gap-3 px-4 py-3 border-b border-navyline last:border-b-0 hover:bg-void normal-case tracking-normal font-body text-sm text-stone hover:text-gold transition-colors duration-150"
                      >
                        <span className="font-mono text-gold text-[10px]">{s.code}</span>
                        {s.name}
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            ) : (
              <NavLink
                key={l.to}
                to={l.to}
                className={({ isActive }) =>
                  `pb-1 border-b-2 transition-colors duration-200 ${
                    isActive ? "text-gold border-gold" : "text-stone border-transparent hover:text-gold"
                  }`
                }
              >
                {l.label}
              </NavLink>
            )
          )}
        </nav>

        <Link
          to="/contact"
          className="hidden md:inline-block bg-gold text-void font-mono text-xs uppercase tracking-widest2 font-medium px-5 py-2.5 hover:bg-goldbright transition-colors duration-200"
        >
          Request Proposal
        </Link>

        <button
          className="md:hidden text-paper w-8 h-8 relative"
          aria-label={open ? "Close menu" : "Open menu"}
          aria-expanded={open}
          onClick={() => setOpen(!open)}
        >
          <span
            className={`absolute left-1 right-1 h-0.5 bg-current transition-transform duration-200 ${
              open ? "rotate-45 top-1/2 -translate-y-1/2" : "top-2.5"
            }`}
          />
          <span
            className={`absolute left-1 right-1 h-0.5 bg-current transition-opacity duration-200 top-1/2 -translate-y-1/2 ${
              open ? "opacity-0" : "opacity-100"
            }`}
          />
          <span
            className={`absolute left-1 right-1 h-0.5 bg-current transition-transform duration-200 ${
              open ? "-rotate-45 top-1/2 -translate-y-1/2" : "bottom-2.5"
            }`}
          />
        </button>
      </div>

      {open && (
        <div className="md:hidden bg-navy border-t border-navyline px-5 pb-6 pt-2">
          <nav className="flex flex-col font-mono text-sm uppercase tracking-widest2">
            {links.map((l) => (
              <NavLink
                key={l.to}
                to={l.to}
                onClick={() => setOpen(false)}
                className={({ isActive }) =>
                  `py-3 border-b border-navyline ${isActive ? "text-gold" : "text-stone"}`
                }
              >
                {l.label}
              </NavLink>
            ))}
          </nav>
          <div className="mt-3">
            <p className="font-mono text-[10px] uppercase tracking-widest2 text-gold mb-2">Services Directory</p>
            {services.map((s) => (
              <Link
                key={s.slug}
                to={`/services/${s.slug}`}
                onClick={() => setOpen(false)}
                className="flex items-baseline gap-3 py-2 text-sm text-stone normal-case"
              >
                <span className="font-mono text-gold text-[10px]">{s.code}</span>
                {s.name}
              </Link>
            ))}
          </div>
        </div>
      )}
    </header>
  );
}
