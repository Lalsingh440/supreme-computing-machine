import { Link } from "react-router-dom";

export default function NotFound() {
  return (
    <div className="bg-void text-paper min-h-[60vh] flex items-center">
      <div className="max-w-6xl mx-auto px-5 md:px-8 py-24">
        <p className="font-mono text-gold text-xs uppercase tracking-widest2 mb-4">Error 404</p>
        <h1 className="font-display font-800 uppercase text-5xl mb-4">Route Not Secured</h1>
        <p className="text-stone/70 max-w-md mb-8">
          This location doesn't exist in our directory. It may have been moved or decommissioned.
        </p>
        <Link
          to="/"
          className="inline-block bg-gold text-void font-mono text-xs uppercase tracking-widest2 px-6 py-4 hover:bg-goldbright transition-colors duration-200"
        >
          Return to Home
        </Link>
      </div>
    </div>
  );
}
