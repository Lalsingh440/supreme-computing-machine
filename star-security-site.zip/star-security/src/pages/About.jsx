import { useState } from "react";
import Eyebrow from "../components/Eyebrow";

const tabs = {
  Mission:
    "Our mission is to provide protection and peace of mind to our clients through a bespoke service tailored to their specific needs; the safety and security of the client's staff, premises, assets, and the general public is our highest priority.",
  Vision: "To be the first choice of our clients for security services in the United Arab Emirates.",
  "Core Values": "Integrity, Sustainability, Unity, Accountability, Commitment, Community.",
};

const branches = ["Abu Dhabi (Head Office)", "Dubai", "Al Ain", "Al Dhafra", "Northern Emirates"];

const accreditations = [
  { code: "ISO 9001", label: "Quality Management System" },
  { code: "ISO 14001", label: "Environmental Management System" },
  { code: "ISO 45001", label: "Occupational Health & Safety" },
];

const team = [
  { name: "Rashid", role: "Project Incharge" },
  { name: "Abhijith", role: "Supervisor" },
  { name: "Faisal", role: "Security Guard" },
  { name: "Anthony", role: "Lifeguard" },
];

export default function About() {
  const [active, setActive] = useState("Mission");

  return (
    <div>
      <section className="bg-navy text-paper">
        <div className="max-w-6xl mx-auto px-5 md:px-8 py-16 md:py-20">
          <Eyebrow dark>Corporate Profile</Eyebrow>
          <h1 className="font-display font-800 uppercase text-4xl md:text-5xl">Who We Are</h1>
          <p className="mt-5 max-w-2xl text-stone/80 leading-relaxed">
            Headquartered in Abu Dhabi, with regional operations branches across the UAE. Star Security
            Services LLC is part of the MQ Holding Group LLC family, leveraging over 15 years of regional
            knowledge and institutional backing.
          </p>
        </div>
      </section>

      {/* Chairman */}
      <section className="max-w-6xl mx-auto px-5 md:px-8 py-16 grid md:grid-cols-3 gap-10 border-b border-stone">
        <div>
          <Eyebrow>Chairman</Eyebrow>
          <h2 className="font-display font-700 uppercase text-2xl text-navy">Mohamed Saeed Abdulla Al Qubaisi</h2>
        </div>
        <div className="md:col-span-2 text-ink/80 leading-relaxed space-y-3">
          <p>
            Mr. Al Qubaisi is a UAE national of Abu Dhabi who owns and manages Star Security Services LLC.
            He serves on the Board of Directors of the Abu Dhabi Chamber of Commerce &amp; Industry, Abu Dhabi
            National Hotels Company, and National Drilling Company.
          </p>
          <p>
            Under his ownership, the company was established in Abu Dhabi in 2006, with the Dubai branch
            following in 2011.
          </p>
        </div>
      </section>

      {/* Mission / Vision / Values tabs */}
      <section className="max-w-6xl mx-auto px-5 md:px-8 py-16 border-b border-stone">
        <Eyebrow>Direction</Eyebrow>
        <div className="flex flex-wrap gap-2 mb-6 mt-1">
          {Object.keys(tabs).map((t) => (
            <button
              key={t}
              onClick={() => setActive(t)}
              className={`font-mono text-xs uppercase tracking-widest2 px-5 py-3 border transition-colors duration-200 ${
                active === t
                  ? "bg-navy text-paper border-navy"
                  : "border-stone text-navy/70 hover:border-navy"
              }`}
            >
              {t}
            </button>
          ))}
        </div>
        <p className="text-lg text-ink/80 leading-relaxed max-w-2xl">{tabs[active]}</p>
      </section>

      {/* Accreditations */}
      <section className="max-w-6xl mx-auto px-5 md:px-8 py-16 border-b border-stone">
        <Eyebrow>Accreditations</Eyebrow>
        <h2 className="font-display font-800 uppercase text-3xl text-navy mb-8">Certified Standards</h2>
        <div className="grid sm:grid-cols-3 border-t border-l border-stone">
          {accreditations.map((a) => (
            <div key={a.code} className="border-r border-b border-stone p-6">
              <p className="font-mono text-gold text-xs uppercase tracking-widest2">{a.code}</p>
              <p className="mt-2 text-ink/80">{a.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Branches */}
      <section className="max-w-6xl mx-auto px-5 md:px-8 py-16 border-b border-stone">
        <Eyebrow>Geographic Presence</Eyebrow>
        <h2 className="font-display font-800 uppercase text-3xl text-navy mb-6">Operating Branches</h2>
        <ul className="flex flex-wrap gap-3">
          {branches.map((b) => (
            <li key={b} className="font-mono text-xs uppercase tracking-widest2 border border-navy/30 text-navy px-4 py-2">
              {b}
            </li>
          ))}
        </ul>
      </section>

      {/* Team */}
      <section className="max-w-6xl mx-auto px-5 md:px-8 py-16">
        <Eyebrow>Operational Roles</Eyebrow>
        <h2 className="font-display font-800 uppercase text-3xl text-navy mb-8">The Team</h2>
        <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-6">
          {team.map((m) => (
            <div key={m.name} className="border-t-2 border-gold pt-4">
              <p className="font-display font-700 text-xl text-navy">{m.name}</p>
              <p className="font-mono text-xs uppercase tracking-widest2 text-ink/50 mt-1">{m.role}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
