import { Link } from "react-router-dom";
import { services } from "../data/services";
import { offices, contact } from "../data/services";

export default function Footer() {
  return (
    <footer className="bg-void text-stone border-t-2 border-gold">
      <div className="max-w-6xl mx-auto px-5 md:px-8 py-14 grid gap-10 md:grid-cols-4">
        <div>
          <p className="font-display text-2xl font-800 text-paper tracking-wide">STAR SECURITY</p>
          <p className="font-mono text-[10px] uppercase tracking-widest2 text-gold mt-1">Services LLC</p>
          <p className="text-sm text-stone/70 mt-4 leading-relaxed">
            Part of the MQ Holding Group LLC. ISO-accredited security operations across the UAE since 2006.
          </p>
        </div>

        <div>
          <p className="font-mono text-[10px] uppercase tracking-widest2 text-gold mb-3">Services</p>
          <ul className="space-y-2 text-sm">
            {services.slice(0, 5).map((s) => (
              <li key={s.slug}>
                <Link to={`/services/${s.slug}`} className="hover:text-gold transition-colors duration-150">
                  {s.name}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <p className="font-mono text-[10px] uppercase tracking-widest2 text-gold mb-3">Offices</p>
          <ul className="space-y-4 text-sm">
            {offices.map((o) => (
              <li key={o.city}>
                <p className="text-paper">{o.city}</p>
                <p className="text-stone/70 leading-relaxed">{o.address}</p>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <p className="font-mono text-[10px] uppercase tracking-widest2 text-gold mb-3">Contact</p>
          <ul className="space-y-2 text-sm">
            <li>{contact.phone}</li>
            <li>WhatsApp: {contact.whatsapp}</li>
            <li>{contact.careersEmail}</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-navyline">
        <p className="max-w-6xl mx-auto px-5 md:px-8 py-4 text-xs font-mono text-stone/50">
          © {new Date().getFullYear()} Star Security Services LLC. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
