export default function Eyebrow({ children, dark = false }) {
  return (
    <p
      className={`font-mono text-[11px] uppercase tracking-widest2 mb-3 ${
        dark ? "text-gold" : "text-navy/60"
      }`}
    >
      {children}
    </p>
  );
}
