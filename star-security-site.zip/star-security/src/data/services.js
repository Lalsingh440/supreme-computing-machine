export const categories = ["All", "Manned Protection", "SMART Solutions", "Niche Operations"];

export const services = [
  {
    code: "01",
    slug: "manned-guarding",
    category: "Manned Protection",
    name: "Manned & Static Guarding",
    short: "Physical protection of premises, personnel and assets by NSI and SIRA licensed guards.",
    methodology: [
      "Detect threats from a distance",
      "Deny threat avenues of approach",
      "Deter and defeat potential threats",
    ],
    applications: [
      "Government buildings",
      "Oilfields and remote environments",
      "Control room operations",
      "Visitor management",
      "Building patrols",
      "Event deployments",
    ],
    licensing: "NSI (National Security Institute) and SIRA (Security Industry Regulatory Agency) licensed.",
  },
  {
    code: "02",
    slug: "smart-security",
    category: "SMART Solutions",
    name: "SMART Electronic Security",
    short: "End-to-end EPIC solutions — Engineer, Procure, Install, Commission — for building security systems.",
    capabilities: [
      "Electronic security design",
      "Systems survey, installation and maintenance",
      "Risk assessment and mitigation",
      "Technology refresh plans",
      "Datacentre and control room solutions",
      "Access control, intrusion and fire detection integration",
    ],
  },
  {
    code: "03",
    slug: "cctv-monitoring",
    category: "SMART Solutions",
    name: "CCTV & Surveillance",
    short: "Control room operations specializing in corporate physical monitoring, data centre security and remote oversight.",
    capabilities: [
      "Corporate physical monitoring",
      "Data centre security",
      "Policy compliance monitoring",
      "Remote operational oversight",
    ],
  },
  {
    code: "04",
    slug: "mobile-security",
    category: "Manned Protection",
    name: "Mobile Patrols",
    short: "Keeping personnel and travelers secure on the move, from transfers to route analysis.",
    capabilities: [
      "Secure airport meet-and-greet transfers",
      "Ground studies and route analysis",
      "Mobile transport security with emergency contingency",
      "First-line medical support",
    ],
  },
  {
    code: "05",
    slug: "k9-security",
    category: "Manned Protection",
    name: "K9 Canine Units",
    short: "Trained protection dogs complementing physical guards to detect threats and secure perimeters.",
    capabilities: [
      "Threat detection",
      "Personnel defense in high-risk situations",
      "Private and industrial perimeter protection",
    ],
  },
  {
    code: "06",
    slug: "maritime-security",
    category: "Manned Protection",
    name: "Maritime & Port Security",
    short: "Tailored solutions for port authorities and marine facilities, compliant with local maritime rules.",
    capabilities: [
      "Experienced maritime consultants",
      "Static marine guards",
      "Electronic access systems",
    ],
  },
  {
    code: "07",
    slug: "risk-consultancy",
    category: "Niche Operations",
    name: "Risk Consultancy",
    short: "Helping commercial and government bodies understand and manage their risk landscape.",
    capabilities: [
      "Cost-effective risk management frameworks",
      "C-suite decision support",
      "Crisis and disaster response planning",
      "Socio-political and systemic environment studies",
    ],
  },
];

export const industries = [
  "Governments",
  "Multinational Corporations & SMEs",
  "Hospitality & Events",
  "Oil & Gas Sector",
  "Engineering & Construction Projects",
  "Educational Institutes",
  "Shopping Malls & Retail Hubs",
];

export const credentials = [
  "ISO 9001:2015",
  "ISO 14001",
  "ISO 45001",
  "ASIS International",
  "SIRA Approved",
  "ASSD Certified",
];

export const metrics = [
  { value: "15+", label: "Years operating across the Emirates" },
  { value: "27+", label: "Nationalities in the security workforce" },
  { value: "2006", label: "Founded in Abu Dhabi" },
  { value: "2011", label: "Dubai branch established" },
];

export const offices = [
  {
    city: "Abu Dhabi — Head Office",
    address: "10th Floor, MQ Building, Muroor Road, Abu Dhabi, United Arab Emirates",
  },
  {
    city: "Dubai Branch",
    address: "Office 212, 2nd Floor, ARENCO Building, Dubai Investment Park (DIP) 1, Dubai, UAE",
  },
];

export const contact = {
  phone: "+971 50 304 2500",
  whatsapp: "+971 56 424 8887",
  careersEmail: "cv@starsecurity.ae",
};
