import { useParams, Link, Navigate } from "react-router-dom";
import Eyebrow from "../components/Eyebrow";
import { services } from "../data/services";

export default function ServiceDetail() {
  const { slug } = useParams();
  const service = services.find((s) => s.slug === slug);

  if (!service) return <Navigate to="/services" replace />;

  const listItems = service.methodology || service.capabilities || [];

  return (
    <div>
      <section className="bg-navy text-paper">
        <div className="max-w-6xl mx-auto px-5 md:px-8 py-16 md:py-20">
          <div className="flex items-center gap-3 mb-4">
            <span className="font-mono text-gold text-sm">{service.code}</span>
            <Link to="/services" className="font-mono text-[11px] uppercase tracking-widest2 text-stone/50 hover:text-gold">
              ← Back to Directory
            </Link>
          </div>
          <Eyebrow dark>{service.category}</Eyebrow>
          <h1 className="font-display font-800 uppercase text-4xl md:text-5xl max-w-3xl">{service.name}</h1>
          <p className="mt-5 max-w-2xl text-stone/80 leading-relaxed">{service.short}</p>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-5 md:px-8 py-16 grid md:grid-cols-3 gap-10 border-b border-stone">
        <div>
          <Eyebrow>{service.methodology ? "Methodology" : "Capabilities"}</Eyebrow>
          <h2 className="font-display font-700 uppercase text-2xl text-navy">
            {service.methodology ? "How It Works" : "What's Included"}
          </h2>
        </div>
        <div className="md:col-span-2">
          <ul className="border-t border-l border-stone grid sm:grid-cols-2">
            {listItems.map((item, i) => (
              <li key={item} className="border-r border-b border-stone p-5 flex gap-3">
                <span className="font-mono text-gold text-xs shrink-0">{String(i + 1).padStart(2, "0")}</span>
                <span className="text-ink/80">{item}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {service.applications && (
        <section className="max-w-6xl mx-auto px-5 md:px-8 py-16 border-b border-stone">
          <Eyebrow>Deployment Contexts</Eyebrow>
          <h2 className="font-display font-800 uppercase text-3xl text-navy mb-6">Applications</h2>
          <div className="flex flex-wrap gap-3">
            {service.applications.map((a) => (
              <span key={a} className="font-mono text-xs uppercase tracking-widest2 border border-navy/30 text-navy px-4 py-2">
                {a}
              </span>
            ))}
          </div>
        </section>
      )}

      {service.licensing && (
        <section className="max-w-6xl mx-auto px-5 md:px-8 py-16 border-b border-stone">
          <Eyebrow>Regulatory Standing</Eyebrow>
          <p className="text-lg text-ink/80 max-w-2xl leading-relaxed">{service.licensing}</p>
        </section>
      )}

      <section className="bg-navy text-paper">
        <div className="max-w-6xl mx-auto px-5 md:px-8 py-16 flex flex-wrap items-center justify-between gap-6">
          <div>
            <Eyebrow dark>Next Step</Eyebrow>
            <h2 className="font-display font-800 uppercase text-2xl md:text-3xl">
              Request a proposal for {service.name}
            </h2>
          </div>
          <Link
            to="/contact"
            className="bg-gold text-void font-mono text-xs uppercase tracking-widest2 font-medium px-7 py-4 hover:bg-goldbright transition-colors duration-200 shrink-0"
          >
            Contact This Department
          </Link>
        </div>
      </section>
    </div>
  );
}
