import { Link } from "react-router-dom";
import Eyebrow from "../components/Eyebrow";
import { services, credentials, metrics } from "../data/services";

export default function Home() {
  const today = new Date().toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });

  return (
    <div>
      {/* HERO — styled as an operations briefing document */}
      <section className="bg-void text-paper relative overflow-hidden">
        <div
          className="absolute inset-0 opacity-[0.07]"
          style={{
            backgroundImage:
              "linear-gradient(#C9A227 1px, transparent 1px), linear-gradient(90deg, #C9A227 1px, transparent 1px)",
            backgroundSize: "48px 48px",
          }}
          aria-hidden="true"
        />
        <div className="relative max-w-6xl mx-auto px-5 md:px-8">
          <div className="flex flex-wrap items-center justify-between gap-2 py-3 border-b border-navyline font-mono text-[11px] uppercase tracking-widest2 text-gold">
            <span>Star Security // Operations Brief</span>
            <span className="text-stone/60">Ref: SSS-HOME-01 &nbsp;·&nbsp; {today}</span>
          </div>

          <div className="py-20 md:py-28 max-w-3xl">
            <Eyebrow dark>Licensed Private Security Provider — UAE</Eyebrow>
            <h1 className="font-display font-800 uppercase text-5xl sm:text-6xl md:text-7xl leading-[0.95] tracking-tight">
              Security<br />Without<br />Barriers.
            </h1>
            <p className="mt-6 text-lg text-stone/80 max-w-xl leading-relaxed">
              Experienced personnel. Advanced technology. Absolute compliance. ISO-accredited security
              operations across the Emirates since 2006.
            </p>
            <div className="mt-9 flex flex-wrap gap-4">
              <Link
                to="/services"
                className="bg-gold text-void font-mono text-xs uppercase tracking-widest2 font-medium px-7 py-4 hover:bg-goldbright transition-colors duration-200"
              >
                Explore Services
              </Link>
              <Link
                to="/contact"
                className="border border-stone/40 text-paper font-mono text-xs uppercase tracking-widest2 px-7 py-4 hover:border-gold hover:text-gold transition-colors duration-200"
              >
                Schedule a Security Audit
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* CREDENTIALS STRIP */}
      <section className="bg-navy text-paper border-b border-navyline">
        <div className="max-w-6xl mx-auto px-5 md:px-8 py-5 flex flex-wrap gap-x-8 gap-y-3 items-center justify-between">
          <span className="font-mono text-[11px] uppercase tracking-widest2 text-stone/50">Accreditations</span>
          <div className="flex flex-wrap gap-x-7 gap-y-2">
            {credentials.map((c) => (
              <span key={c} className="font-mono text-xs uppercase tracking-wide text-stone/90">
                {c}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* METRICS */}
      <section className="bg-paper border-b border-stone">
        <div className="max-w-6xl mx-auto px-5 md:px-8 py-14 grid grid-cols-2 md:grid-cols-4 gap-8">
          {metrics.map((m) => (
            <div key={m.label} className="border-l-2 border-gold pl-4">
              <p className="font-display font-700 text-4xl text-navy leading-none">{m.value}</p>
              <p className="text-sm text-ink/60 mt-2 leading-snug">{m.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* SERVICES MANIFEST */}
      <section className="max-w-6xl mx-auto px-5 md:px-8 py-20">
        <div className="flex items-end justify-between mb-8 flex-wrap gap-3">
          <div>
            <Eyebrow>Capability Manifest</Eyebrow>
            <h2 className="font-display font-800 uppercase text-3xl md:text-4xl text-navy">Core Services</h2>
          </div>
          <Link to="/services" className="font-mono text-xs uppercase tracking-widest2 text-navy border-b-2 border-gold pb-1 hover:text-gold transition-colors duration-200">
            View full directory →
          </Link>
        </div>

        <div className="border-t border-stone">
          {services.slice(0, 3).map((s) => (
            <Link
              key={s.slug}
              to={`/services/${s.slug}`}
              className="group flex items-center gap-6 py-6 border-b border-stone hover:bg-navy transition-colors duration-200 px-2 -mx-2"
            >
              <span className="font-mono text-sm text-gold w-8 shrink-0">{s.code}</span>
              <div className="flex-1">
                <p className="font-display font-700 uppercase text-xl md:text-2xl text-navy group-hover:text-paper transition-colors duration-200">
                  {s.name}
                </p>
                <p className="text-sm text-ink/60 group-hover:text-stone/70 transition-colors duration-200 mt-1 max-w-xl">
                  {s.short}
                </p>
              </div>
              <span className="font-mono text-xs uppercase tracking-widest2 text-navy/40 group-hover:text-gold transition-colors duration-200 hidden sm:inline">
                Detail →
              </span>
            </Link>
          ))}
        </div>
      </section>

      {/* MQ HOLDING TRUST BLOCK */}
      <section className="bg-navy text-paper">
        <div className="max-w-6xl mx-auto px-5 md:px-8 py-16 grid md:grid-cols-3 gap-8 items-start">
          <div className="md:col-span-1">
            <Eyebrow dark>Institutional Backing</Eyebrow>
            <h2 className="font-display font-800 uppercase text-2xl">MQ Holding Group LLC</h2>
          </div>
          <div className="md:col-span-2 text-stone/80 leading-relaxed">
            <p>
              Star Security Services LLC is owned and managed by Mr. Mohamed Saeed Abdulla Al Qubaisi, who
              serves on the Board of Directors of the Abu Dhabi Chamber of Commerce &amp; Industry, Abu Dhabi
              National Hotels Company, and National Drilling Company. The company operates as part of the
              MQ Holding Group LLC family, established in Abu Dhabi in 2006 with a Dubai branch following in 2011.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
